Algoritmo ReservaUPN
	
	
	
	Definir codigo Como Cadena
	
	Definir valido, estudianteYaReservo Como Logico
	
	Definir reservaHecha, salir Como Logico
	
	Definir i, opcion, recurso, horas Como Entero
	
	Definir totalReservas Como Entero
	
	Definir tipoRegistro, codigoRegistro Como Cadena
	
	Definir recursoRegistro, horasRegistro Como Entero
	
	Definir dispComputadoras, dispSalas, dispLibros, dispJuegos Como Entero
	
	
	
	Dimension dispComputadoras[5]
	
	Dimension dispSalas[3]
	
	Dimension dispLibros[5]
	
	Dimension dispJuegos[4]
	
	
	
	Dimension tipoRegistro[100]
	
	Dimension codigoRegistro[100]
	
	Dimension recursoRegistro[100]
	
	Dimension horasRegistro[100]
	
	
	
	Para i <- 1 Hasta 5 Hacer
		
		dispComputadoras[i] <- 1
		
		dispLibros[i] <- 1
		
	FinPara
	
	
	
	Para i <- 1 Hasta 3 Hacer
		
		dispSalas[i] <- 1
		
	FinPara
	
	
	
	Para i <- 1 Hasta 4 Hacer
		
		dispJuegos[i] <- 1
		
	FinPara
	
	
	
	totalReservas <- 0
	
	salir <- Falso
	
	
	
	Repetir
		
		Escribir ""
		
		Escribir "===== SISTEMA DE RESERVAS ====="
		
		Escribir "Ingrese su codigo de estudiante:"
		
		Leer codigo
		
		codigo <- Mayusculas(codigo)
		
		
		
		valido <- Verdadero
		
		
		
		Si Longitud(codigo) <> 9 Entonces
			
			valido <- Falso
			
		SiNo
			
			Si Subcadena(codigo, 1, 3) <> "N00" Entonces
				
				valido <- Falso
				
			FinSi
			
			
			
			Para i <- 4 Hasta 9 Hacer
				
				Si Subcadena(codigo, i, i) < "0" O Subcadena(codigo, i, i) > "9" Entonces
					
					valido <- Falso
					
				FinSi
				
			FinPara
			
		FinSi
		
		
		
		Si valido = Falso Entonces
			
			Escribir "ERROR: Codigo de estudiante invalido."
			
		SiNo
			
			
			
			estudianteYaReservo <- Falso
			
			
			
			Si totalReservas > 0 Entonces
				
				Para i <- 1 Hasta totalReservas Hacer
					
					Si codigoRegistro[i] = codigo Entonces
						
						estudianteYaReservo <- Verdadero
						
					FinSi
					
				FinPara
				
			FinSi
			
			
			
			Si estudianteYaReservo Entonces
				
				Escribir "ERROR: Este estudiante ya realizo una reserva."
				
			SiNo
				
				
				
				Escribir "Codigo correcto. Bienvenido."
				
				
				
				reservaHecha <- Falso
				
				
				
				Repetir
					
					Escribir ""
					
					Escribir "===== MENU PRINCIPAL ====="
					
					Escribir "1. Reservar computadora"
					
					Escribir "2. Reservar sala de trabajo"
					
					Escribir "3. Reservar libro"
					
					Escribir "4. Reservar juego de mesa"
					
					Escribir "5. Consultar disponibilidad"
					
					Escribir "6. Ver registro de reservas"
					
					Escribir "7. Salir"
					
					Escribir "Elija una opcion:"
					
					Leer opcion
					
					
					
					Segun opcion Hacer
						
						
						
						1:
							
							Si totalReservas < 100 Entonces
								
								Escribir "Computadoras disponibles:"
								
								Para i <- 1 Hasta 5 Hacer
									
									Escribir i, ". Computadora ", i, " - Disponible: ", dispComputadoras[i]
									
								FinPara
								
								
								
								Escribir "Elija una computadora (1-5):"
								
								Leer recurso
								
								
								
								Si recurso >= 1 Y recurso <= 5 Entonces
									
									Si dispComputadoras[recurso] = 1 Entonces
										
										Escribir "Ingrese la cantidad de horas (1-8):"
										
										Leer horas
										
										
										
										Si horas >= 1 Y horas <= 8 Entonces
											
											dispComputadoras[recurso] <- 0
											
											totalReservas <- totalReservas + 1
											
											tipoRegistro[totalReservas] <- "Computadora"
											
											codigoRegistro[totalReservas] <- codigo
											
											recursoRegistro[totalReservas] <- recurso
											
											horasRegistro[totalReservas] <- horas
											
											
											
											Escribir "Reserva registrada correctamente."
											
											Escribir "Estudiante: ", codigo
											
											Escribir "Computadora: ", recurso
											
											Escribir "Horas reservadas: ", horas
											
											
											
											reservaHecha <- Verdadero
											
										SiNo
											
											Escribir "Cantidad de horas invalida."
											
										FinSi
										
									SiNo
										
										Escribir "Esta computadora no esta disponible."
										
									FinSi
									
								SiNo
									
									Escribir "Opcion de computadora invalida."
									
								FinSi
								
							SiNo
								
								Escribir "Se alcanzo el limite de 100 reservas."
								
							FinSi
							
							
							
						2:
							
							Si totalReservas < 100 Entonces
								
								Escribir "Salas de trabajo disponibles:"
								
								Para i <- 1 Hasta 3 Hacer
									
									Escribir i, ". Sala ", i, " - Disponible: ", dispSalas[i]
									
								FinPara
								
								
								
								Escribir "Elija una sala (1-3):"
								
								Leer recurso
								
								
								
								Si recurso >= 1 Y recurso <= 3 Entonces
									
									Si dispSalas[recurso] = 1 Entonces
										
										Escribir "Ingrese la cantidad de horas (1-8):"
										
										Leer horas
										
										
										
										Si horas >= 1 Y horas <= 8 Entonces
											
											dispSalas[recurso] <- 0
											
											totalReservas <- totalReservas + 1
											
											tipoRegistro[totalReservas] <- "Sala"
											
											codigoRegistro[totalReservas] <- codigo
											
											recursoRegistro[totalReservas] <- recurso
											
											horasRegistro[totalReservas] <- horas
											
											
											
											Escribir "Sala reservada correctamente."
											
											reservaHecha <- Verdadero
											
										SiNo
											
											Escribir "Cantidad de horas invalida."
											
										FinSi
										
									SiNo
										
										Escribir "Esta sala no esta disponible."
										
									FinSi
									
								SiNo
									
									Escribir "Opcion de sala invalida."
									
								FinSi
								
							SiNo
								
								Escribir "Se alcanzo el limite de 100 reservas."
								
							FinSi
							
							
							
						3:
							
							Si totalReservas < 100 Entonces
								
								Escribir "Libros disponibles:"
								
								Para i <- 1 Hasta 5 Hacer
									
									Escribir i, ". Libro ", i, " - Disponible: ", dispLibros[i]
									
								FinPara
								
								
								
								Escribir "Elija un libro (1-5):"
								
								Leer recurso
								
								
								
								Si recurso >= 1 Y recurso <= 5 Entonces
									
									Si dispLibros[recurso] = 1 Entonces
										
										dispLibros[recurso] <- 0
										
										totalReservas <- totalReservas + 1
										
										tipoRegistro[totalReservas] <- "Libro"
										
										codigoRegistro[totalReservas] <- codigo
										
										recursoRegistro[totalReservas] <- recurso
										
										horasRegistro[totalReservas] <- 0
										
										
										
										Escribir "Libro reservado correctamente."
										
										reservaHecha <- Verdadero
										
									SiNo
										
										Escribir "Este libro no esta disponible."
										
									FinSi
									
								SiNo
									
									Escribir "Opcion de libro invalida."
									
								FinSi
								
							SiNo
								
								Escribir "Se alcanzo el limite de 100 reservas."
								
							FinSi
							
							
							
						4:
							
							Si totalReservas < 100 Entonces
								
								Escribir "Juegos de mesa disponibles:"
								
								Para i <- 1 Hasta 4 Hacer
									
									Escribir i, ". Juego ", i, " - Disponible: ", dispJuegos[i]
									
								FinPara
								
								
								
								Escribir "Elija un juego (1-4):"
								
								Leer recurso
								
								
								
								Si recurso >= 1 Y recurso <= 4 Entonces
									
									Si dispJuegos[recurso] = 1 Entonces
										
										dispJuegos[recurso] <- 0
										
										totalReservas <- totalReservas + 1
										
										tipoRegistro[totalReservas] <- "Juego"
										
										codigoRegistro[totalReservas] <- codigo
										
										recursoRegistro[totalReservas] <- recurso
										
										horasRegistro[totalReservas] <- 0
										
										
										
										Escribir "Juego reservado correctamente."
										
										reservaHecha <- Verdadero
										
									SiNo
										
										Escribir "Este juego no esta disponible."
										
									FinSi
									
								SiNo
									
									Escribir "Opcion de juego invalida."
									
								FinSi
								
							SiNo
								
								Escribir "Se alcanzo el limite de 100 reservas."
								
							FinSi
							
							
							
						5:
							
							Escribir "===== DISPONIBILIDAD ====="
							
							Escribir "Computadoras:"
							
							Para i <- 1 Hasta 5 Hacer
								
								Escribir "Computadora ", i, ": ", dispComputadoras[i]
								
							FinPara
							
							
							
							Escribir "Salas:"
							
							Para i <- 1 Hasta 3 Hacer
								
								Escribir "Sala ", i, ": ", dispSalas[i]
								
							FinPara
							
							
							
							Escribir "Libros:"
							
							Para i <- 1 Hasta 5 Hacer
								
								Escribir "Libro ", i, ": ", dispLibros[i]
								
							FinPara
							
							
							
							Escribir "Juegos:"
							
							Para i <- 1 Hasta 4 Hacer
								
								Escribir "Juego ", i, ": ", dispJuegos[i]
								
							FinPara
							
							
							
							Escribir "1 = Disponible; 0 = No disponible."
							
							
							
						6:
							
							Escribir "===== REGISTRO DE RESERVAS ====="
							
							
							
							Si totalReservas = 0 Entonces
								
								Escribir "Todavia no hay reservas registradas."
								
							SiNo
								
								Para i <- 1 Hasta totalReservas Hacer
									
									Escribir "Reserva numero: ", i
									
									Escribir "Estudiante: ", codigoRegistro[i]
									
									Escribir "Tipo: ", tipoRegistro[i]
									
									Escribir "Recurso numero: ", recursoRegistro[i]
									
									
									
									Si horasRegistro[i] > 0 Entonces
										
										Escribir "Horas: ", horasRegistro[i]
										
									FinSi
									
									
									
									Escribir "------------------------"
									
								FinPara
								
							FinSi
							
							
							
						7:
							
							Escribir "Gracias por utilizar el sistema."
							
							salir <- Verdadero
							
							
							
						De Otro Modo:
							
							Escribir "Opcion invalida. Intente nuevamente."
							
							
							
					FinSegun
					
					
					
				Hasta Que reservaHecha = Verdadero O salir = Verdadero
				
				
				
			FinSi
			
		FinSi
		
		
		
	Hasta Que salir = Verdadero
	
	
	
FinAlgoritmo